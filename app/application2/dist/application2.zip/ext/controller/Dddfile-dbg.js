sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        met1: function(oEvent) {
            MessageToast.show("");
        }
    };
});
